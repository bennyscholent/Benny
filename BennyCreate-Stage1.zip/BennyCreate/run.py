"""Verify travel times and the stage's tests before allowing a new handoff."""
import json
import os
import subprocess
import sys
from pathlib import Path

from stage1 import Paused, UTC, datetime, window


def main():
    config = json.loads(Path("config.json").read_text())
    travel = json.loads(os.environ["BENNY_TRAVEL"] or "null") if "BENNY_TRAVEL" in os.environ else config["travel"]
    try:
        window(travel, datetime.now(UTC))
    except Paused as exc:
        print(f"PAUSED: {exc}")
        return 3
    tests = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], timeout=30)
    if tests.returncode:
        print("REVIEW REQUIRED: Stage 1 tests failed.", file=sys.stderr)
        return 1
    return subprocess.run([sys.executable, "stage1.py"]).returncode


if __name__ == "__main__":
    sys.exit(main())
