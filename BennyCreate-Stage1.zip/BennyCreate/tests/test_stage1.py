import json
import unittest
from datetime import timedelta
from pathlib import Path
from unittest.mock import Mock

import stage1 as s

STAY = dict(city="London", timezone="Europe/London", arrive="2026-11-09T00:00:00Z",
            candles="2026-11-13T15:59:00Z", havdalah="2026-11-14T17:00:00Z",
            depart="2026-11-14T23:00:00Z")
NOW = s.timestamp("2026-11-12T13:00:00Z")
XML = b"""<rss><channel><item><title>Night trains</title>
<pubDate>Thu, 12 Nov 2026 11:00:00 GMT</pubDate></item></channel></rss>"""


class ResearchTests(unittest.TestCase):
    def setUp(self):
        self.cfg = json.loads(Path("config.json").read_text())
        self.cfg.update(travel=STAY, min_signals=1, market="US", manual_signals=[])
        self.cfg["rules"]["banned_terms"] = []
        self.row = next(s.topics(XML, "US"))

    def test_handoff(self):
        result = s.research(self.cfg, lambda: NOW, lambda url: XML)
        self.assertEqual(result["signals"], [self.row])
        self.assertEqual(result["approval"], "pending")

    def test_travel_pause_before_network(self):
        reader = Mock()
        for travel, moment in [(None, NOW), (STAY, s.timestamp(STAY["candles"])),
                               (STAY, s.timestamp(STAY["depart"])),
                               (STAY, s.timestamp(STAY["candles"]) - timedelta(seconds=179))]:
            self.cfg["travel"] = travel
            with self.assertRaises(s.Paused):
                s.research(self.cfg, lambda: moment, reader)
        reader.assert_not_called()
        s.window(STAY, s.timestamp(STAY["havdalah"]))

    def test_stale_future_and_wrong_market(self):
        for row in [dict(self.row, market="GB"),
                    dict(self.row, observed_at=(NOW + timedelta(hours=1)).isoformat()),
                    dict(self.row, observed_at=(NOW - timedelta(days=4)).isoformat())]:
            with self.assertRaises(ValueError):
                s.gate([row], self.cfg, NOW)

    def test_dedup_and_banned(self):
        self.assertEqual(len(s.gate([self.row, dict(self.row, title="  NIGHT   trains ")], self.cfg, NOW)), 1)
        self.cfg["rules"]["banned_terms"] = ["TrAiN"]
        with self.assertRaises(ValueError):
            s.gate([self.row], self.cfg, NOW)

    def test_refresh_and_retry_limit(self):
        reader = Mock(side_effect=[b"broken", XML])
        self.assertEqual(s.research(self.cfg, lambda: NOW, reader, Mock())["attempts"], 2)
        reader = Mock(side_effect=TimeoutError())
        with self.assertRaises(ValueError):
            s.research(self.cfg, lambda: NOW, reader, Mock())
        self.assertEqual(reader.call_count, 4)

    def test_manual_evidence_and_fallback(self):
        signal = dict(self.row, source="TikTok Creative Center", kind="sound",
                      evidence="https://ads.tiktok.com/business/creativecenter/inspiration/popular/music/pc/en")
        self.cfg["manual_signals"] = [signal]
        out = s.research(self.cfg, lambda: NOW, Mock(side_effect=TimeoutError()))
        self.assertEqual(out["signals"], [signal])
        with self.assertRaises(ValueError):
            s.gate([dict(signal, evidence="https://example.com")], self.cfg, NOW)

    def test_boundary_before_handoff(self):
        clock = Mock(side_effect=[NOW, s.timestamp(STAY["candles"])])
        with self.assertRaises(s.Paused):
            s.research(self.cfg, clock, lambda url: XML)
