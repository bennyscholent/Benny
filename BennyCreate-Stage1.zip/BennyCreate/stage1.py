"""BennyCreate trend research. Python 3.11+, standard library."""
import json
import os
import re
import signal
import sys
import tempfile
import time
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

UTC = timezone.utc


class Paused(Exception):
    pass


def timestamp(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("Timestamp requires a UTC offset")
    return result


def window(travel, now):
    """One confirmed stay and one Friday/Saturday pair. Expire on departure."""
    try:
        zone = ZoneInfo(travel["timezone"])
        start, candles, havdalah, end = [
            timestamp(travel[key]).astimezone(zone)
            for key in ("arrive", "candles", "havdalah", "depart")
        ]
        if not (travel["city"].strip() and start < end and candles < havdalah
                and candles.weekday() == 4 and havdalah.weekday() == 5
                and (havdalah.date() - candles.date()).days == 1
                and start.date() >= candles.date() - timedelta(days=5)
                and end.date() < candles.date() + timedelta(days=2)):
            raise ValueError
    except (TypeError, ValueError, KeyError, AttributeError, ZoneInfoNotFoundError):
        raise Paused("Confirm city, stay dates, candle lighting and Havdalah.") from None
    if not start <= now < end or candles <= now < havdalah:
        raise Paused("Outside confirmed working time.")
    cutoff = min(end, candles) if now < candles else end
    if cutoff - now < timedelta(minutes=3):
        raise Paused("Too close to the end of the working window.")


def google_feed(market):
    return f"https://trends.google.com/trending/rss?geo={market}"


def fetch(url):
    with urlopen(Request(url, headers={"User-Agent": "BennyCreate/1.0"}), timeout=15) as response:
        data = response.read(2_000_001)
    if len(data) > 2_000_000:
        raise ValueError("Feed size limit")
    return data


def topics(data, market):
    root = ET.fromstring(data)
    for item in root.findall("./channel/item"):
        try:
            observed = parsedate_to_datetime(item.findtext("pubDate", "")).isoformat()
        except (ValueError, TypeError, OverflowError):
            continue
        yield dict(kind="topic", title=item.findtext("title", ""),
                   source="Google Trends", evidence=google_feed(market),
                   observed_at=observed, market=market)


def gate(rows, config, now):
    seen, passed = set(), []
    for row in rows:
        title = " ".join(unicodedata.normalize("NFKC", row["title"]).split())
        age = now - timestamp(row["observed_at"])
        key = (row["kind"], title.casefold())
        if not title or key in seen or row["market"] != config["market"]:
            continue
        if not timedelta(0) <= age <= timedelta(hours=config["max_age_hours"]):
            continue
        if any(term.casefold() in title.casefold() for term in config["rules"]["banned_terms"]):
            continue
        if row["source"] == "Google Trends":
            valid = row["kind"] == "topic" and row["evidence"] == google_feed(config["market"])
        else:
            link = urlsplit(row["evidence"])
            valid = (row["source"] == "TikTok Creative Center"
                     and row["kind"] in ("sound", "hashtag")
                     and link.scheme == "https" and link.netloc == "ads.tiktok.com"
                     and link.path.startswith("/business/creativecenter/"))
        if valid:
            passed.append({**row, "title": title})
            seen.add(key)
    if len(passed) < config["min_signals"]:
        raise ValueError("Insufficient fresh, distinct, sourced signals")
    return passed


def research(config, clock, reader=fetch, sleep=time.sleep):
    if not re.fullmatch("[A-Z]{2}", config["market"]) or not 1 <= config["min_signals"] <= 100:
        raise ValueError("Check market and min_signals")
    if not 0 < config["max_age_hours"] <= 168:
        raise ValueError("max_age_hours must be within one week")
    for attempt in range(4):
        now = clock()
        window(config["travel"], now)
        try:
            rows = list(topics(reader(google_feed(config["market"])), config["market"]))
        except (ValueError, ET.ParseError, OSError) as exc:
            rows = []
            print(f"Feed unavailable ({type(exc).__name__})", file=sys.stderr)
        try:
            now = clock()
            window(config["travel"], now)
            signals = gate(rows + config["manual_signals"], config, now)
            return dict(stage=1, status="passed", observed_at=now.isoformat(),
                        attempts=attempt + 1, signals=signals, approval="pending")
        except ValueError as exc:
            if attempt == 3:
                raise
            print(f"{exc}. Refreshing sources.", file=sys.stderr)
            sleep(2 ** attempt)


def main():
    config = json.loads(Path("config.json").read_text())
    if "BENNY_TRAVEL" in os.environ:
        config["travel"] = json.loads(os.environ["BENNY_TRAVEL"] or "null")
    clock = lambda: datetime.now(UTC)
    window(config["travel"], clock())
    # Hard runtime bound on Linux/macOS, including a server that trickles bytes.
    signal.alarm(110)
    result = research(config, clock)
    with tempfile.NamedTemporaryFile(mode="w", dir=".", delete=False) as f:
        tmp = Path(f.name)
        json.dump(result, f, indent=2, ensure_ascii=False)
    try:
        window(config["travel"], clock())
        tmp.replace("trends.json")
    finally:
        tmp.unlink(missing_ok=True)
    print(f"PASS: {len(result['signals'])} signals in trends.json")
    signal.alarm(0)


if __name__ == "__main__":
    try:
        main()
    except Paused as exc:
        print(f"PAUSED: {exc}")
        sys.exit(3)
    except (OSError, TypeError, KeyError, ValueError) as exc:
        print(f"REVIEW REQUIRED: {exc}", file=sys.stderr)
        sys.exit(1)
