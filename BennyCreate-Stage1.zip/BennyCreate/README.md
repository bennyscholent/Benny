# BennyCreate · Stage 1
Research for five original vertical reels per active day, each adapted for Instagram, TikTok, YouTube Shorts, LinkedIn and Facebook. Publication requires Benny's approval. Only the research stage is implemented in this release.

## Architecture
Confirmed travel window → stage test suite → official Google Trends RSS + optional manually observed TikTok sounds/hashtags → normalize, deduplicate, validate evidence and freshness → atomic trends.json handoff. Insufficient signals trigger a fresh fetch with 1, 2 and 4 second delays, then a failed run for review. A failing code test blocks the run immediately and requires a code fix.

Planned after confirmation: trend signals → ten scored concepts and hook variants → 15–30 second scripts → voice and captions → 9:16 assembly → technical, originality, policy and score checks → Benny approves a specific cut → platform publishing → weekly performance feedback. The research feed supplies leads. Matching them to a clip and scoring creative fit belong to Stage 2.

## Install and test
Unzip, open a terminal in BennyCreate and use Python 3.11+ on macOS/Linux. No pip dependencies.
```sh
python3 --version
python3 -m unittest discover -s tests -v
python3 run.py
```
In the shipped configuration, tests pass and the last command prints PAUSED (exit 3). This is the expected first run. For a live handoff follow the travel setup.

## Confirm each stay
Create travel.json privately. Copy the JSON below and replace every example value with your actual city, IANA time zone, arrival, departure, and the candle-lighting and Havdalah times you follow there. Use explicit UTC offsets. Confirm times from your local calendar; the software does not guess a custom or read phone GPS. During travel keep the stay current, ending it at departure. Set a separate window for each stop, and renew weekly. Keep arrival/departure between the Sunday preceding the configured Friday and the end of Saturday. For a longer stay split the week at Saturday 23:59:59 local and renew on Sunday.
```json
{"city":"London","timezone":"Europe/London","arrive":"2026-11-09T10:00:00+00:00","candles":"2026-11-13T15:59:00+00:00","havdalah":"2026-11-14T17:00:00+00:00","depart":"2026-11-14T22:00:00+00:00"}
```
```sh
BENNY_TRAVEL="$(cat travel.json)" python3 run.py
```
A current stay outside Shabbos permits research. Missing/expired coverage, Shabbos or less than three minutes until the cutoff pauses it. Use run.py as the production entry point. Only exit code 0 authorizes consumption of that run's trends.json. Failed or paused runs leave earlier successful files intact. A fresh runner per cloud run isolates outputs.

## Markets and sources
Start with Google Trends RSS (free, no key). The default research market is US as an editable starting point for broad English-language reach. The travel city controls only the pause. Change market, max_age_hours, min_signals, and rules.banned_terms in config.json. Gate defaults: three distinct signals, observed in the last 48 hours, matching market, documented source and no banned term. Feed results may cover sport, news and other topics outside your niche.

Free complementary source: visit TikTok Creative Center, select your market and manually add observed sounds or hashtags to manual_signals. Use the real title, actual observation timestamp and official chart URL. An entry records a chart observation, not permission to use a recording. These entries can pass when the RSS service is unavailable if they meet the same minimum. Example shape:
```json
{"kind":"hashtag","title":"<observed hashtag>","source":"TikTok Creative Center","market":"US","observed_at":"<ISO timestamp with offset>","evidence":"https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en"}
```
Sources: [Google Trends export help](https://support.google.com/trends/answer/3076011), [US RSS](https://trends.google.com/trending/rss?geo=US), [TikTok Creative Center](https://ads.tiktok.com/business/creativecenter/). No scraping, media downloading or social credentials. An official Creative Center URL is checked for origin, not independently verified for the manually entered ranking.

## Run in the cloud with the Mac off
Use a GitHub repository you control with standard GitHub-hosted Linux runners. In a private repository confirm that your account blocks paid Actions usage before enabling the schedule. Private repo minutes and artifact storage share account allowances. Local execution also costs no service fees. The ZIP has no cloud deployment or account credentials.

With Git and GitHub CLI installed and authenticated, first create travel.json as above. From the unzipped folder:
```sh
git init -b main
git add .
git commit -m "Add BennyCreate trend research"
gh repo create BennyCreate --private --source=. --remote=origin --push
gh secret set BENNY_TRAVEL < travel.json
gh workflow run research.yml
gh run list --workflow research.yml
```
If BennyCreate already exists in GitHub, copy these files into the desired repository instead. Keep travel.json out of version control. Set the secret again whenever your itinerary changes. The included workflow schedules one research batch daily at 06:17 UTC on the default branch. A scheduled runner may wake, check out code and check the clock during Shabbos; it skips research, tests and artifact upload on a paused run. For zero scheduler activity, disable the workflow before Shabbos and enable it afterward. Scheduling can be delayed or skipped by the host. Download the successful run's trends artifact from Actions within one day. See failed-run logs for REVIEW REQUIRED and enable GitHub Actions failure notifications to receive flags. A skipped daily run waits for the next scheduled or manual run. No publishing or downstream stages are enabled.
